TEDXID="paris";
TEDXLIST = [
  {
    "id":"2011",
    "label":"2011 : Futurs singuliers",
    "image":"https://lh6.googleusercontent.com/-JuXT9pCAWF0/TTMpt3QPnOI/AAAAAAAAXvA/CWoFJQqh6ng/s912/Salle%252520%25252821%252529.jpg",
    "meta":{
      "youtube":"EB4E907286FE3EC2",
      "title":"TEDxParis",
      "twitter":"tedxparis"
    }
  },
  {
    "id":"2010",
    "label":"2010 : Libérez l'étincelle",
    "image":"http://www.tedxparis.com/wp-content/uploads/slideshow-gallery-2/4320727159_8b5264db19_z.jpg",
    "meta":{
      "youtube":"0548DCF75693BB71"
    }
  }
];