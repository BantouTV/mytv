Joshfire.define(['./app', 'joshfire/class', 'joshfire/vendor/underscore', './api/joshfire.me', './ted.ios'], function(App, Class, _, JoshmeAPI, BaseApp) {

  return Class(BaseApp, {
    fullscreenCheck:function() {
      
    }
  });
  
});
